"""Markdown/LaTeX/HTML -> plain text, so markdown-emitting extractors (Docling,
Marker, MinerU) are compared on CONTENT, not on markup.

ONE implementation: effectcheck's Docling backend (ec_docling_extract.py) and the
extractor-pilot harness (tests/harness/extractor_pilot/mdplain.py re-exports this)
both use it, so the package and the measurement cannot drift apart.
Self-test: python ec_mdplain.py effectcheck reads plain
text; '*p* < .05' or '$\\eta^2_p$' would otherwise be scored as a lost statistic.

Conservative: only removes markup and maps a closed list of LaTeX symbols. It
never rewrites digits, signs or relational operators that are already text.
"""
from __future__ import annotations

import html
import re

LATEX_SYMBOLS = {
    r"\chi": "χ", r"\eta": "η", r"\beta": "β", r"\alpha": "α", r"\omega": "ω",
    r"\epsilon": "ε", r"\varepsilon": "ε", r"\rho": "ρ", r"\tau": "τ", r"\mu": "μ",
    r"\sigma": "σ", r"\Delta": "Δ", r"\delta": "δ", r"\phi": "φ", r"\lambda": "λ",
    r"\leq": "≤", r"\le": "≤", r"\geq": "≥", r"\ge": "≥", r"\neq": "≠", r"\pm": "±",
    r"\times": "×", r"\cdot": "·", r"\approx": "≈", r"\sim": "~", r"\%": "%",
    r"\lt": "<", r"\gt": ">", r"\ldots": "...", r"\dots": "...", r"\,": " ", r"\;": " ",
    r"\ ": " ", r"\!": "", r"\quad": " ", r"\qquad": " ", r"\left": "", r"\right": "",
}
SUP = str.maketrans("0123456789+-", "⁰¹²³⁴⁵⁶⁷⁸⁹⁺⁻")


def _latex(expr: str) -> str:
    s = expr
    s = re.sub(r"\\(?:text|mathrm|mathit|mathbf|textit|textbf|operatorname|mathcal)\s*\{([^{}]*)\}", r"\1", s)
    for k in sorted(LATEX_SYMBOLS, key=len, reverse=True):
        s = re.sub(re.escape(k) + r"(?![A-Za-z])", lambda _m, v=LATEX_SYMBOLS[k]: v, s)
    s = re.sub(r"\^\{?(\d)\}?", lambda m: m.group(1).translate(SUP), s)   # ^2 / ^{2} -> ²
    s = re.sub(r"_\{([^{}]*)\}", r"\1", s)                                 # _{p} -> p
    s = re.sub(r"_([A-Za-z0-9])", r"\1", s)                                # _p -> p
    s = s.replace("{", "").replace("}", "")
    return s


def md_to_plain(md: str) -> str:
    s = md
    s = re.sub(r"<!--.*?-->", "", s, flags=re.S)
    s = re.sub(r"!\[[^\]]*\]\([^)]*\)", "", s)                     # images
    s = re.sub(r"\[([^\]]+)\]\([^)]*\)", r"\1", s)                 # links -> text
    s = re.sub(r"\$\$(.+?)\$\$", lambda m: _latex(m.group(1)), s, flags=re.S)
    s = re.sub(r"(?<!\\)\$(.+?)(?<!\\)\$", lambda m: _latex(m.group(1)), s)
    s = re.sub(r"\\\((.+?)\\\)", lambda m: _latex(m.group(1)), s)
    s = re.sub(r"<sup>\s*(\d)\s*</sup>", lambda m: m.group(1).translate(SUP), s, flags=re.I)
    s = re.sub(r"<br\s*/?>", " ", s, flags=re.I)
    s = re.sub(r"</?(?:td|th)[^>]*>", "\t", s, flags=re.I)
    s = re.sub(r"</tr\s*>", "\n", s, flags=re.I)
    # Only REAL tags (letter right after '<'). A bare '<[^>]+>' would eat
    # "p < .001, η<sup>" -- the statistic's own '<' up to the next tag's '>'.
    s = re.sub(r"</?[A-Za-z][A-Za-z0-9]*(?:\s[^<>]*)?/?>", "", s)
    s = html.unescape(s)
    out = []
    for line in s.splitlines():
        if re.fullmatch(r"\s*\|?\s*:?-{3,}:?\s*(\|\s*:?-{3,}:?\s*)*\|?\s*", line):
            continue                                               # table separator row
        if line.lstrip().startswith("|") and line.rstrip().endswith("|"):
            line = "\t".join(c.strip() for c in line.strip()[1:-1].split("|"))
        line = re.sub(r"^\s{0,3}#{1,6}\s+", "", line)              # headings
        line = re.sub(r"^\s*[-*+]\s+", "", line)                   # bullets
        line = re.sub(r"(\*\*|__)(.+?)\1", r"\2", line)            # bold
        line = re.sub(r"(?<![\w*])\*(?!\s)(.+?)(?<!\s)\*(?![\w*])", r"\1", line)  # *italic*
        line = re.sub(r"(?<![\w_])_(?!\s)(.+?)(?<!\s)_(?![\w_])", r"\1", line)    # _italic_
        line = line.replace("\\*", "*").replace("\\_", "_").replace("\\#", "#")
        out.append(line)
    return "\n".join(out)


if __name__ == "__main__":
    import sys
    tests = {
        "found at *p* < .05 and **t**(48) = 2.31": "found at p < .05 and t(48) = 2.31",
        r"$\eta^2_p$ = .12, $\chi^2(1, N = 100)$ = 3.9": "η²p = .12, χ²(1, N = 100) = 3.9",
        "| M | SD |\n|---|---|\n| 2.1 | 0.4 |": "M\tSD\n2.1\t0.4",
        "a_b_c snake_case and 2*3*4": "a_b_c snake_case and 2*3*4",
        "t(48) = -2.31": "t(48) = -2.31",
        "F(1, 742) = 101.10, p < .001, η<sup>2</sup>p = 0.12, CI[0.08, 0.17]), and x > y":
            "F(1, 742) = 101.10, p < .001, η²p = 0.12, CI[0.08, 0.17]), and x > y",
        "η<sub>p</sub><sup>2</sup> = .05, p<.01 and p>.10": "ηp² = .05, p<.01 and p>.10",
    }
    bad = 0
    for i, o in tests.items():
        got = md_to_plain(i)
        if got != o:
            bad += 1
            print(f"FAIL {i!r}\n  got  {got!r}\n  want {o!r}")
    print("self-test:", "FAIL" if bad else "OK")
    sys.exit(1 if bad else 0)
