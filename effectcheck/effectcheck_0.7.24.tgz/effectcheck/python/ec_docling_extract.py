"""effectcheck's Docling backend: one PDF -> plain text + table cell grids (JSON).

Usage: python ec_docling_extract.py <in.pdf> <out.json>
Run with the python of a venv that has `docling` installed (CPU is enough).

Pipeline: Docling standard PDF pipeline, OCR OFF (born-digital PDFs), table
structure ON (TableFormer, ACCURATE mode -- Docling's default, stated explicitly
so a default change upstream cannot silently change what we ran).
Text: Docling's markdown converted to plain text by ec_mdplain.md_to_plain (the
same converter the extractor comparison used), so effectcheck reads content, not
markup. Tables: every TableItem's cells with their row/column offsets and spans,
caption, footnotes and page -- typed later by ec_flatten_grids.py.

Models: when DOCLING_ARTIFACTS_PATH (or ~/.cache/docling/models) exists it is used
and every weight file in it is reported with its sha256, so a result can name
the exact weights that were available to the run. With no local artifacts,
Docling downloads its models and `models` is reported empty -- never guessed.
"""
from __future__ import annotations

import hashlib
import importlib.metadata as md
import json
import os
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ec_mdplain import md_to_plain  # noqa: E402

WEIGHT_SUFFIXES = {".safetensors", ".onnx", ".pt", ".bin"}


def sha256_file(p: Path) -> str:
    h = hashlib.sha256()
    with p.open("rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def main() -> int:
    from docling.datamodel.base_models import InputFormat
    from docling.datamodel.pipeline_options import PdfPipelineOptions, TableFormerMode
    from docling.document_converter import DocumentConverter, PdfFormatOption

    pdf, dst = Path(sys.argv[1]), Path(sys.argv[2])
    art_env = os.environ.get("DOCLING_ARTIFACTS_PATH")
    art = Path(art_env) if art_env else Path.home() / ".cache" / "docling" / "models"
    art_used = art if art.is_dir() else None
    opts = PdfPipelineOptions(do_ocr=False, do_table_structure=True,
                              artifacts_path=str(art_used) if art_used else None)
    opts.table_structure_options.mode = TableFormerMode.ACCURATE
    conv = DocumentConverter(format_options={InputFormat.PDF: PdfFormatOption(pipeline_options=opts)})

    t0 = time.perf_counter()
    doc = conv.convert(str(pdf)).document
    secs = time.perf_counter() - t0

    tables = []
    for i, t in enumerate(doc.tables):
        cells = [{"r": c.start_row_offset_idx, "c": c.start_col_offset_idx,
                  "rowspan": c.row_span, "colspan": c.col_span, "text": c.text or "",
                  "is_header": bool(c.column_header)}
                 for c in t.data.table_cells]
        foot = []
        for ref in getattr(t, "footnotes", None) or []:
            try:
                foot.append(ref.resolve(doc).text)
            except Exception:  # noqa: BLE001 - a footnote we cannot resolve is just absent
                pass
        tables.append({"id": f"docling-t{i + 1}",
                       "label": None,
                       "caption": t.caption_text(doc) or None,
                       "footnote": " ".join(foot) or None,
                       "page": t.prov[0].page_no if t.prov else 0,
                       "cells": cells})

    models = []
    if art_used:
        for p in sorted(art_used.rglob("*")):
            if p.is_file() and p.suffix in WEIGHT_SUFFIXES:
                models.append({"file": p.relative_to(art_used).as_posix(), "sha256": sha256_file(p)})

    out = {"engine": "docling",
           "engine_version": md.version("docling"),
           "docling_core_version": md.version("docling-core"),
           "settings": {"pipeline": "standard", "do_ocr": False, "do_table_structure": True,
                        "table_mode": "accurate", "text": "export_to_markdown -> ec_mdplain.md_to_plain",
                        "artifacts_path": str(art_used) if art_used else None},
           "models": models,
           "seconds": round(secs, 2),
           "text": md_to_plain(doc.export_to_markdown()),
           "tables": tables}
    dst.write_text(json.dumps(out, ensure_ascii=False), encoding="utf-8")
    return 0


if __name__ == "__main__":
    sys.exit(main())
