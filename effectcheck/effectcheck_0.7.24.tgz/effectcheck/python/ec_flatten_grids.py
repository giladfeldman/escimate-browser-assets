"""Type table cell grids from ANY extractor into docpluck `flattened_rows` records.

Usage: python ec_flatten_grids.py <in.json> <out.json>

in.json:  {"tables": [{"id", "label", "caption", "footnote", "page",
                       "cells": [{"r", "c", "rowspan", "colspan", "text", "is_header"}]}]}
out.json: {"typer", "typer_version", "n_tables", "n_tables_with_rows", "rows": [FlattenedRow]}

Why docpluck's own typer: effectcheck's `table_rows` input is docpluck's
`flattened_rows` format, produced by `docpluck.tables.flatten.flatten_table`
(~2,000 lines of header/column-role heuristics, MIT licence). Feeding GROBID's or
Docling's cell grids through that SAME function makes an extractor comparison
differ only in which cells the extractor found -- not in who wrote the better
typer. Each grid is treated exactly like a docpluck PDF capture:
  * cells pass through `repair_cells` (docpluck's glyph repairs) with no layout,
    so only the text-level repairs run -- docpluck's own captures get the same;
  * `rendering = "lattice"` (a PDF grid): the header split is docpluck's
    heuristic, never a header the extractor declared (only DOCX `markup`
    declares one), so the two sides are judged by one rule;
  * `caption_status` is "matched" when its label, head or caption names a
    "Table N" (Arabic, letter-prefixed or Roman) and
    "uncaptioned_candidate" otherwise -- effectcheck drops the latter, as it
    does for docpluck's own uncaptioned grids.
A table the typer cannot use yields no rows; it is counted, never invented.
"""
from __future__ import annotations

import json
import re
import sys

# Sub-numbered labels ("Table 1.2", "Table A.1") keep their whole number so they
# cannot collide with "Table 1" (round-2 consult 2026-10-08, F-E); a trailing
# period ("Table 3.") is punctuation, not a sub-number.
_NUM = r"(?:[A-Z]?\d+(?:\.\d+)*[A-Za-z]?|[A-Z]\.\d+(?:\.\d+)*|[IVXLC]+)"
LABEL_RE = re.compile(r"^\s*(?:Table|TABLE)\s+(" + _NUM + r")(?![A-Za-z0-9])")
BARE_RE = re.compile(r"^\s*(" + _NUM + r")\s*[.:]?\s*$")


def table_label(label: str | None, head: str | None, caption: str | None) -> str | None:
    """'Table N' from the first of label, head, caption that names one. A bare
    label ('3', '3.', 'II') counts only in the label slot. Roman numerals are
    accepted. (Sonnet consult 2026-10-08, F7: a GROBID label '3.' used to hide
    a head 'Table 3', and every row of that table was then dropped.)"""
    if label:
        m = LABEL_RE.match(str(label)) or BARE_RE.match(str(label))
        if m:
            return f"Table {m.group(1)}"
    for s in (head, caption):
        if s:
            m = LABEL_RE.match(str(s))
            if m:
                return f"Table {m.group(1)}"
    return None


def main() -> int:
    from docpluck import __version__ as dp_version
    from docpluck.tables.cell_cleaning import repair_cells
    from docpluck.tables.flatten import flatten_table

    src, dst = sys.argv[1], sys.argv[2]
    with open(src, encoding="utf-8") as fh:
        tables = json.load(fh).get("tables") or []
    rows: list[dict] = []
    n_with = 0
    for i, t in enumerate(tables):
        cells = [{"r": int(c["r"]), "c": int(c["c"]),
                  "rowspan": int(c.get("rowspan") or 1), "colspan": int(c.get("colspan") or 1),
                  "text": str(c.get("text") or ""), "is_header": bool(c.get("is_header")),
                  "bbox": (0.0, 0.0, 0.0, 0.0)}
                 for c in (t.get("cells") or [])]
        if not cells:
            continue
        repair_cells(cells, layout=None)
        label = table_label(t.get("label"), t.get("head"), t.get("caption"))
        table = {
            "id": t.get("id") or f"t{i + 1}",
            "label": label,
            "page": int(t.get("page") or 0),
            "caption": t.get("caption"),
            "footnote": t.get("footnote"),
            "kind": "structured",
            "rendering": "lattice",
            "cells": cells,
            "caption_status": "matched" if label else "uncaptioned_candidate",
        }
        out = flatten_table(table)
        n_with += bool(out)
        rows.extend(out)
    with open(dst, "w", encoding="utf-8") as fh:
        json.dump({"typer": "docpluck.tables.flatten.flatten_table", "typer_version": dp_version,
                   "n_tables": len(tables), "n_tables_with_rows": n_with, "rows": rows},
                  fh, ensure_ascii=False)
    return 0


if __name__ == "__main__":
    sys.exit(main())
